const Blog = () => {
  window.location.replace('https://blog.covid19india.org');
};

export default Blog;
